ScottPlot API Documentation:
* [ScottPlot 4.1](api)
* ScottPlot 5.0 (still in development)

Additional Links:
* [ScottPlot.NET Home Page](https://scottplot.net/)
* [ScottPlot 4 Cookbook](https://scottplot.net/cookbook/4.1/)
* [ScottPlot FAQ](https://scottplot.net/faq/)
* [ScottPlot on GitHub](https://github.com/scottplot/scottplot)