# ScottPlot Deployment Notes

### Cookbook

Build and deploy with GitHub Actions (via the website repository)

* https://github.com/ScottPlot/ScottPlot.NET/actions

TODO: generate and deploy locally (because it's an uncomfortably long task for GitHub Actions)

### Demo Applications

Build, bundle, and deploy locally using the `DemoPackager` project

### NuGet Package

Build and deploy using GitHub actions

* https://github.com/ScottPlot/ScottPlot/actions